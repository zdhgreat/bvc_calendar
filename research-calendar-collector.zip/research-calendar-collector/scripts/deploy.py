#!/usr/bin/env python3
"""Deploy and diagnose the collection-only research-calendar runtime."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import venv
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable


SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_DIR = SKILL_ROOT / "assets" / "runtime-template"
EXAMPLE_COMPANY_LISTS = TEMPLATE_DIR / "config" / "company_lists.example.json"
DEFAULT_RUNTIME = Path(
    os.getenv(
        "RESEARCH_CALENDAR_RUNTIME_DIR",
        Path.home() / ".local" / "share" / "agent-runtime" / "research-calendar-collector",
    )
).expanduser()
MUTABLE_RELATIVE_PATHS = {
    Path("events.json"),
    Path("data"),
    Path("config/company_lists.json"),
    Path("config/runtime.env"),
}


def _is_mutable(relative: Path) -> bool:
    return any(relative == item or item in relative.parents for item in MUTABLE_RELATIVE_PATHS)


def _copy_template(runtime: Path) -> list[str]:
    copied = []
    for source in sorted(TEMPLATE_DIR.rglob("*")):
        if not source.is_file():
            continue
        relative = source.relative_to(TEMPLATE_DIR)
        if _is_mutable(relative):
            continue
        destination = runtime / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied.append(str(relative))
    return copied


def _load_active_list(path: Path) -> str:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        return str(payload.get("active_list") or "").strip()
    except Exception:
        return ""


def _write_runtime_env(
    runtime: Path,
    python_bin: Path,
    company_lists: Path,
    active_list: str,
    rewrite: bool,
) -> None:
    destination = runtime / "config" / "runtime.env"
    if destination.exists() and not rewrite:
        return
    values = {
        "COMPANY_LIST_TOOL": runtime / "scripts" / "company_list_source.py",
        "COMPANY_LIST_CONFIG": company_lists,
        "RESEARCH_CALENDAR_PYTHON": python_bin,
        "RESEARCH_CALENDAR_LIST": active_list,
    }
    lines = [f"{key}={shlex.quote(str(value))}" for key, value in values.items() if str(value)]
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_manifest(runtime: Path, copied: Iterable[str]) -> None:
    files = {}
    for relative in copied:
        path = runtime / relative
        files[relative] = _sha256(path)
    payload = {
        "skill": "research-calendar-collector",
        "skill_source": str(SKILL_ROOT),
        "deployed_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "runtime_dir": str(runtime),
        "managed_files": files,
    }
    target = runtime / "data" / "deployment_manifest.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _install_dependencies(runtime: Path, with_a_share: bool) -> Path:
    env_dir = runtime / ".venv"
    if not (env_dir / "bin" / "python").exists():
        venv.EnvBuilder(with_pip=True).create(env_dir)
    python_bin = env_dir / "bin" / "python"
    requirements = runtime / "scripts" / "requirements.txt"
    subprocess.run(
        [str(python_bin), "-m", "pip", "install", "-r", str(requirements)],
        check=True,
    )
    if with_a_share:
        subprocess.run(
            [
                str(python_bin),
                "-m",
                "pip",
                "install",
                "-r",
                str(runtime / "scripts" / "requirements-a-share.txt"),
            ],
            check=True,
        )
    return python_bin


def deploy(args: argparse.Namespace) -> int:
    runtime = args.runtime_dir.expanduser().resolve()
    runtime.mkdir(parents=True, exist_ok=True)
    copied = _copy_template(runtime)

    destination_lists = runtime / "config" / "company_lists.json"
    destination_lists.parent.mkdir(parents=True, exist_ok=True)
    if args.company_lists:
        source_lists = args.company_lists.expanduser().resolve()
        if not source_lists.exists():
            raise FileNotFoundError(f"Company-list file does not exist: {source_lists}")
        if source_lists != destination_lists:
            shutil.copy2(source_lists, destination_lists)
    elif not destination_lists.exists():
        shutil.copy2(EXAMPLE_COMPANY_LISTS, destination_lists)

    events = runtime / "events.json"
    if not events.exists():
        events.write_text('{"events": []}\n', encoding="utf-8")
    (runtime / "data").mkdir(exist_ok=True)

    python_bin = Path(args.python).expanduser()
    if args.install_deps:
        python_bin = _install_dependencies(runtime, args.with_a_share)

    active_list = _load_active_list(destination_lists)
    _write_runtime_env(
        runtime,
        python_bin,
        destination_lists,
        active_list,
        args.rewrite_env,
    )
    _write_manifest(runtime, copied)

    print(json.dumps({
        "status": "deployed",
        "runtime_dir": str(runtime),
        "company_lists": str(destination_lists),
        "active_list": active_list,
        "python": str(python_bin),
        "managed_file_count": len(copied),
    }, ensure_ascii=False, indent=2))
    return 0


def _read_env(path: Path) -> Dict[str, str]:
    values: Dict[str, str] = {}
    if not path.exists():
        return values
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        parsed = shlex.split(value)
        values[key] = parsed[0] if parsed else ""
    return values


def _run_check(command: list[str], cwd: Path, env: Dict[str, str]) -> Dict[str, object]:
    result = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    return {
        "ok": result.returncode == 0,
        "exit_code": result.returncode,
        "output": result.stdout[-3000:].strip(),
    }


def doctor(args: argparse.Namespace) -> int:
    runtime = args.runtime_dir.expanduser().resolve()
    runtime_env = _read_env(runtime / "config" / "runtime.env")
    env = os.environ.copy()
    env.update(runtime_env)
    python_bin = env.get("RESEARCH_CALENDAR_PYTHON") or sys.executable

    required = [
        "events.json",
        "config/company_lists.json",
        "config/ir_sources.json",
        "scripts/company_list_source.py",
        "scripts/company_list_workflow.py",
        "scripts/ir_crawler.py",
        "scripts/ir_event_extractor.py",
        "scripts/ir_crawler_wrapper.sh",
    ]
    missing = [relative for relative in required if not (runtime / relative).exists()]
    checks = {
        "runtime_exists": runtime.exists(),
        "missing_files": missing,
        "dependencies": _run_check(
            [python_bin, "-c", "import requests, bs4; print('ok')"],
            runtime,
            env,
        ) if not missing else {"ok": False, "output": "required files missing"},
        "company_lists": _run_check(
            [python_bin, "scripts/company_list_workflow.py", "status"],
            runtime,
            env,
        ) if not missing else {"ok": False, "output": "required files missing"},
        "source_config": _run_check(
            [python_bin, "scripts/ir_crawler.py", "--list"],
            runtime,
            env,
        ) if not missing else {"ok": False, "output": "required files missing"},
    }
    ok = (
        checks["runtime_exists"]
        and not missing
        and checks["dependencies"]["ok"]
        and checks["company_lists"]["ok"]
        and checks["source_config"]["ok"]
    )
    print(json.dumps({
        "status": "ok" if ok else "blocked",
        "runtime_dir": str(runtime),
        "python": python_bin,
        "checks": checks,
    }, ensure_ascii=False, indent=2))
    return 0 if ok else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    deploy_parser = subparsers.add_parser("deploy", help="install or update a runtime")
    deploy_parser.add_argument("--runtime-dir", type=Path, default=DEFAULT_RUNTIME)
    deploy_parser.add_argument("--company-lists", type=Path)
    deploy_parser.add_argument("--python", default=sys.executable)
    deploy_parser.add_argument("--install-deps", action="store_true")
    deploy_parser.add_argument("--with-a-share", action="store_true")
    deploy_parser.add_argument(
        "--rewrite-env",
        action="store_true",
        help="replace an existing runtime.env with generated values",
    )
    deploy_parser.set_defaults(func=deploy)

    doctor_parser = subparsers.add_parser("doctor", help="run local deployment checks")
    doctor_parser.add_argument("--runtime-dir", type=Path, default=DEFAULT_RUNTIME)
    doctor_parser.set_defaults(func=doctor)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
