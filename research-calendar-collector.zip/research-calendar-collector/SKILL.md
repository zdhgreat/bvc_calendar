---
name: research-calendar-collector
description: Deploy, configure, run, audit, and query a local multi-watchlist investment research calendar covering official company IR calendars, earnings releases and calls, Investor/Analyst/Capital Markets Days, shareholder meetings, disclosure schedules, and dividend dates. Use when an agent needs a collection-only 投研日历 workflow without Feishu document publishing or Glance page generation.
---

# 投研日历采集版

Use this Skill directory as immutable shared source. Keep company lists, event
history, coverage state, caches, credentials, browser profiles, and generated
reports in a machine-local runtime directory.

This copy is collection-only. Do not add Feishu document publishing or Glance
page generation, refresh, or verification to its workflow.

## Deploy

Run from the Skill root:

```bash
python3 scripts/deploy.py deploy \
  --runtime-dir "$HOME/.local/share/agent-runtime/research-calendar-collector" \
  --company-lists "/path/to/company_lists.json" \
  --install-deps

python3 scripts/deploy.py doctor \
  --runtime-dir "$HOME/.local/share/agent-runtime/research-calendar-collector"
```

Set `RESEARCH_CALENDAR_RUNTIME_DIR` to change the default runtime. Deployment
updates shared code and source definitions but preserves runtime events, state,
company lists, credentials, and local configuration.

Read [references/deployment.md](references/deployment.md) when configuring
company-list paths, Chrome fallback, or a scheduler. Read
[references/data-contract.md](references/data-contract.md) before changing event
deduplication or reporting run status.

## Preflight

From the runtime directory:

```bash
python3 scripts/company_list_workflow.py status
python3 scripts/company_list_workflow.py audit-sources --out data/source_gap_audit/latest.json
python3 scripts/ir_crawler.py --list
```

Treat a missing company-list file, unknown list, missing IR source mapping, or
unavailable required browser path as blocked. Never translate those states into
“无新增”.

## Run

Use the unified wrapper for a formal daily run:

```bash
WATCHLISTS="BV Watchlist" bash scripts/ir_crawler_wrapper.sh
WATCHLISTS="BV Watchlist,Deo Watchlist" bash scripts/ir_crawler_wrapper.sh
```

Use bounded commands for diagnosis:

```bash
python3 scripts/ir_crawler.py --all --company-list "BV Watchlist"
python3 scripts/dividend_calendar.py --company-list "BV Watchlist"
python3 scripts/query.py 60
python3 calendar_notify.py list 30
```

The generic IR layer scans every configured `supplemental_urls` entry and
recognizes earnings/results, earnings calls, Investor Day, Analyst Day, Capital
Markets Day, investor conferences, and AGM events. It supports English,
Chinese, and Japanese dates, exact time/timezone capture, multiple events in one
release, RSS detail-page follow-up, and historical-release filtering.

## Acceptance

After every formal run, inspect:

```bash
python3 scripts/ir_crawler.py --check-coverage
python3 scripts/query.py 60
python3 scripts/deploy.py doctor --runtime-dir "$RESEARCH_CALENDAR_RUNTIME_DIR"
```

Also read:

- `events.json`
- `data/daily_workflow_state.json`
- `data/ir_coverage_state.json`
- `data/source_gap_audit/latest.json`
- `data/dividend_state.json`
- `data/crawl_failures.json`, when present
- `data/needs_notification.txt`, when present

Report execution and company coverage separately:

- `success=true` means configured collection stages executed successfully.
- `coverage_complete=false` or `status=partial_coverage` means at least one
  company still lacks executable company-level IR coverage.
- A failed page, unparsed scheduling signal, partial source, or protected-source
  failure is incomplete, not no-new-events.

Completion for this copy is limited to the verified local event store and state
files. Do not treat any external document or page as part of its acceptance.

## Source Maintenance

Add company source mappings to the runtime `config/ir_sources.json`, then run
the source-gap audit and extractor tests. Prefer official IR calendars, event
pages, RSS/news releases, presentations, and regulatory schedules. Keep source
cadence conservative; do not parallelize protected or anti-bot sources.

Do not add company-specific extraction code until the generic parser and
configuration-driven supplemental paths have been tested and shown
insufficient.

