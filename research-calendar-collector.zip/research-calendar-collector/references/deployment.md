# Deployment Reference

## Runtime Boundary

The Skill directory is shared, immutable source. Deploy each Agent to a
separate runtime unless Agents intentionally coordinate on one event database.

Default runtime:

```text
~/.local/share/agent-runtime/research-calendar-collector
```

Mutable runtime files:

- `config/company_lists.json`
- `config/runtime.env`
- `events.json`
- `data/`
- `.venv/`
- browser profiles, cookies, logs, and generated reports

Never place credentials, cookies, API keys, browser profiles, event history, or
a user-maintained company list in the Agent platform Skill directory.

## Company Lists

Pass a compatible JSON file during deployment:

```bash
python3 scripts/deploy.py deploy \
  --company-lists "/path/to/company_lists.json"
```

The file must contain `active_list` and `lists`. Each list contains `companies`.
Company entries may include:

- `name`, `company_name_cn`, `company_name_en`
- `code`, `market`, `securities`
- `ir_sources`: IDs defined in runtime `config/ir_sources.json`

Use `COMPANY_LIST_CONFIG` to point at a live shared file instead of the runtime
copy. Use `COMPANY_LIST_TOOL` only when another compatible global management
script should replace the bundled implementation.

## Environment

The wrapper loads `config/runtime.env`. Supported settings:

- `COMPANY_LIST_CONFIG`
- `COMPANY_LIST_TOOL`
- `RESEARCH_CALENDAR_PYTHON`
- `RESEARCH_CALENDAR_LIST`
- `CHROME_CDP_URL`

Keep secrets in a separate machine-local secret store or process environment.

## Browser Fallback

Some official IR sites return 403 or a browser challenge to command-line HTTP
clients. Configure a real local Chrome DevTools endpoint with `CHROME_CDP_URL`.
If the fallback is unavailable, report the source as protected-source failure.
Do not report zero events.

## Scheduling

Use the receiving Agent's native automation system. The formal command is:

```bash
WATCHLISTS="Example Watchlist" bash scripts/ir_crawler_wrapper.sh
```

Do not install systemd or launchd units automatically from the shared Skill.
The scheduler must run with live network access and the same runtime
environment used by `doctor`.

This collector copy ends after local event and state verification. It has no
external document publishing or page refresh stage.

