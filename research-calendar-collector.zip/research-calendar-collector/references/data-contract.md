# Data And Status Contract

## Event Store

`events.json` is an object containing an `events` array. Canonical event fields:

- `id`
- `date`: `YYYY-MM-DD`
- `title`
- `type`
- `company`, when available
- `time`, only when an exact hour/minute is known
- `timezone`
- `source`
- `source_url`
- `note`
- `created_at`

Do not invent an exact time. Convert non-China times to Beijing time only when
the source time and timezone are known.

## Deduplication

Deduplicate equivalent company/date/event records across source layers.
Prefer the record with:

1. Exact time and timezone.
2. Event-detail URL rather than a generic archive page.
3. More specific event title.
4. Official source provenance.

Do not merge genuinely distinct events occurring on the same date.

## Coverage

`data/ir_coverage_state.json` records configured source execution. A source is:

- `complete`: all configured paths were fetched and parsed.
- `partial`: at least one path failed or contained an unparsed schedule signal.
- `failed`: the source-level collector did not complete.

`data/source_gap_audit/latest.json` records company-level source design gaps.
A successful configured-source run does not imply every company has a source.

`data/daily_workflow_state.json` is the formal run summary:

- `success`: configured collection stages executed successfully.
- `coverage_complete`: no high-risk company source gaps remain.
- `status=success`: execution and company coverage are complete.
- `status=partial_coverage`: execution succeeded but company coverage is not
  complete.
- `status=incomplete`: at least one required collection stage failed.

Never use “无新增” when the run is partial, failed, blocked, or protected-source
recovery did not complete.

The acceptance boundary is local: verify `events.json` and the state files
above. External document and page state are intentionally outside this copy.

