#!/usr/bin/env python3
"""投研日历查询工具"""
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

CALENDAR_FILE = Path(__file__).resolve().parent.parent / "events.json"

def load():
    with open(CALENDAR_FILE, encoding='utf-8') as f:
        return json.load(f)['events']

def query(days=60):
    events = load()
    today = datetime.now()
    limit = today + timedelta(days=days)
    
    future = [e for e in events 
              if today <= datetime.strptime(e['date'][:10], '%Y-%m-%d') <= limit]
    future.sort(key=lambda x: x['date'])
    
    seen = set()
    results = []
    for e in future:
        title = e['title']
        for p in ['May 13, 2026 7:00 AM EDT : ', '15/05/2026 7:00 AM EDT : ']:
            title = title.replace(p, '')
        if title in ['View all', 'Events & Presentations', '6:40 AM MDT', '8:40 AM EDT']:
            continue
        key = (e['date'], title[:20])
        if key not in seen:
            seen.add(key)
            results.append(e)
    
    return results

if __name__ == '__main__':
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 60
    results = query(days)
    for e in results:
        title = e['title']
        for p in ['May 13, 2026 7:00 AM EDT : ', '15/05/2026 7:00 AM EDT : ']:
            title = title.replace(p, '')
        note = f' | {e["note"][:50]}' if e.get('note') else ''
        company = f' [{e.get("company", "")}]' if e.get('company') else ''
        t = e.get('time', '')
        tz = e.get('timezone', '')
        time_str = f' [{t} {tz}]' if t else ''
        print(f'{e["date"][:10]}{company} | {title}{time_str}{note}')
