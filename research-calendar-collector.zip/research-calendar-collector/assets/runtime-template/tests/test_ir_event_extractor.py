#!/usr/bin/env python3

import sys
import unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from ir_event_extractor import extract_events_from_html, extract_forward_ir_events


class IrEventExtractorTest(unittest.TestCase):
    def setUp(self):
        self.today = datetime(2026, 7, 31)

    def test_scheduled_financial_results_with_jst_time(self):
        result = extract_forward_ir_events(
            "First quarter of FY2026 financial results "
            "(Scheduled on Jul. 31, 2026 at 15:30 p.m. (JST))",
            title="First quarter of FY2026 financial results",
            link="https://example.com/news",
            company="Example",
            today=self.today,
        )
        self.assertEqual(len(result["events"]), 1)
        event = result["events"][0]
        self.assertEqual(event["date"], "2026-07-31")
        self.assertEqual(event["time"], "15:30")
        self.assertEqual(event["timezone"], "JST")
        self.assertEqual(event["type"], "财报")

    def test_one_release_can_contain_two_future_events(self):
        result = extract_forward_ir_events(
            "Sandisk to Report Fiscal Fourth Quarter and Fiscal Year 2026 Results "
            "on August 5, 2026; Announces Investor Day on August 13, 2026",
            title=(
                "Sandisk to Report Fiscal Fourth Quarter and Fiscal Year 2026 Results "
                "on August 5, 2026; Announces Investor Day on August 13, 2026"
            ),
            link="https://example.com/release",
            company="Sandisk",
            today=self.today,
        )
        self.assertEqual(
            {(event["date"], event["type"]) for event in result["events"]},
            {("2026-08-05", "财报"), ("2026-08-13", "投资者会议")},
        )

    def test_past_results_release_is_not_a_scheduling_signal(self):
        result = extract_forward_ir_events(
            "Company reports second quarter 2026 financial results and revenue growth.",
            title="Company Reports Second Quarter Results",
            link="https://example.com/release",
            company="Example",
            today=self.today,
        )
        self.assertEqual(result["events"], [])
        self.assertEqual(result["unparsed_signals"], [])

    def test_unparsed_scheduled_event_is_reported(self):
        result = extract_forward_ir_events(
            "The company will announce financial results in early August.",
            title="Financial results schedule",
            link="https://example.com/release",
            company="Example",
            today=self.today,
        )
        self.assertEqual(result["events"], [])
        self.assertEqual(len(result["unparsed_signals"]), 1)

    def test_resolved_past_schedule_is_not_reported_as_unparsed(self):
        result = extract_forward_ir_events(
            "The company will report financial results on July 23, 2026.",
            title="Company to report financial results",
            link="https://example.com/release",
            company="Example",
            today=self.today,
        )
        self.assertEqual(result["events"], [])
        self.assertEqual(result["unparsed_signals"], [])

    def test_html_uses_specific_item_link(self):
        html = """
        <ul>
          <li class="box">
            <a href="/news/result-date.html">
              First quarter financial results scheduled on August 7, 2026 at 4:30 PM ET
            </a>
          </li>
        </ul>
        """
        result = extract_events_from_html(
            html,
            page_url="https://example.com/news",
            company="Example",
            today=self.today,
        )
        self.assertEqual(len(result["events"]), 1)
        self.assertEqual(
            result["events"][0]["source_url"],
            "https://example.com/news/result-date.html",
        )
        self.assertEqual(result["events"][0]["time"], "16:30")
        self.assertEqual(result["events"][0]["timezone"], "ET")


if __name__ == "__main__":
    unittest.main()
