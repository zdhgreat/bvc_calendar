#!/usr/bin/env python3
"""
股票投研日历
记录和查看未来重要事件
"""

import json
import re
from datetime import datetime, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
EVENTS_FILE = SCRIPT_DIR / "events.json"


# ============================================================
# 去重逻辑：日期 + 公司名 + 事件关键词 三要素相同即判重
# ============================================================

COMPANY_ALIASES = {
    "腾讯": "腾讯", "tencent": "腾讯",
    "新东方": "新东方", "new oriental": "新东方",
    "SK海力士": "SK海力士", "sk hynix": "SK海力士", "sk海力士": "SK海力士",
    "三星电子": "三星电子", "samsung": "三星电子",
    "英特尔": "英特尔", "intel": "英特尔",
    "英伟达": "英伟达", "nvidia": "英伟达",
    "美光": "美光", "micron": "美光",
    "瑞幸": "瑞幸", "luckin": "瑞幸", "瑞幸咖啡": "瑞幸",
    "海尔智家": "海尔智家", "haier": "海尔智家",
    "美的集团": "美的集团", "midea": "美的集团",
    "格力电器": "格力电器", "gree": "格力电器",
    "育碧": "育碧", "ubisoft": "育碧",
    "铠侠": "铠侠", "kioxia": "铠侠",
    "Staar": "Staar Surgical", "staar surgical": "Staar Surgical",
    "Prosus": "Prosus", "prosus": "Prosus",
    "华住": "华住", "h world": "华住",
    "唯品会": "唯品会", "vipshop": "唯品会",
    "欢聚": "欢聚", "joyy": "欢聚",
    "亚朵": "亚朵", "atour": "亚朵",
    "拼多多": "拼多多", "pdd": "拼多多",
}

EVENT_KEYWORD_PATTERNS = [
    (r'第[一二三四]季度.*?(?:业绩|财报|earnings|results)', lambda m: {
        '一': 'Q1业绩', '二': 'Q2业绩', '三': 'Q3业绩', '四': 'Q4业绩'
    }.get(m.group(0)[1], '业绩发布')),
    (r'Q1.*?(?:业绩|财报|earnings|results)', 'Q1业绩'),
    (r'Q2.*?(?:业绩|财报|earnings|results)', 'Q2业绩'),
    (r'Q3.*?(?:业绩|财报|earnings|results)', 'Q3业绩'),
    (r'(?:全年|年度|Q4|FY|annual).*?(?:业绩|财报|earnings|results)', '全年业绩'),
    (r'(?:业绩|财报|earnings|results).*?(?:发布|公布|conference|call)', '业绩发布'),
    (r'(?:一季报|半年报|三季报|年报)', lambda m: m.group(0)),
    (r'Quarterly.*?Earnings', '季度业绩'),
    (r'Earnings.*?Conference', '业绩会议'),
    (r'Financial Results', '业绩发布'),
    (r'(?:股东大会|stockholders.*?meeting|annual.*?meeting)', '股东大会'),
    (r'(?:conference|summit|论坛|峰会)', '会议'),
    (r'(?:投资者|investor).*?(?:活动|日历|event)', '投资者活动'),
    (r'Investor Day', '投资者日'),
]


def normalize_company(title: str, source: str = "", note: str = "") -> str:
    """从标题、来源或备注中提取并标准化公司名"""
    text = (title + ' ' + source + ' ' + note).lower()
    for alias, standard in sorted(COMPANY_ALIASES.items(), key=lambda x: -len(x[0])):
        if alias.lower() in text:
            return standard
    return ""


def extract_event_keyword(title: str) -> str:
    """从标题中提取事件关键词（核心动作）"""
    title_lower = title.lower()
    for pattern, replacement in EVENT_KEYWORD_PATTERNS:
        m = re.search(pattern, title_lower)
        if m:
            if callable(replacement):
                return replacement(m)
            return replacement
    return title[:20]


def normalize_keyword(keyword: str) -> str:
    """标准化事件关键词，将相似关键词映射到统一形式"""
    keyword_lower = keyword.lower()
    
    # 第X季度 → QX业绩
    q_map = {'第一': 'Q1', '第二': 'Q2', '第三': 'Q3', '第四': 'Q4', '一': 'Q1', '二': 'Q2', '三': 'Q3', '四': 'Q4'}
    for k, v in q_map.items():
        if k in keyword_lower:
            return f'{v}业绩'
    # 一季报 / Q1 → Q1业绩
    if '一季报' in keyword_lower or keyword_lower == 'q1':
        return 'Q1业绩'
    # 半年报 / Q2 → Q2业绩
    if '半年报' in keyword_lower or keyword_lower == 'q2':
        return 'Q2业绩'
    # 三季报 / Q3 → Q3业绩
    if '三季报' in keyword_lower or keyword_lower == 'q3':
        return 'Q3业绩'
    # 年报 / Q4 / 全年 / 年度 → 全年业绩
    if '年报' in keyword_lower or keyword_lower == 'q4' or '全年' in keyword_lower or '年度' in keyword_lower:
        return '全年业绩'
    # 股东大会 → 股东大会
    if '股东大会' in keyword_lower:
        return '股东大会'
    # 业绩 / 财报 / earnings → 业绩发布
    if re.search(r'(?:财报|业绩|earnings|results)', keyword_lower):
        return '业绩发布'
    # 会议 / conference → 会议
    if re.search(r'(?:会议|conference|summit)', keyword_lower):
        return '会议'
    
    return keyword


def make_dedup_key(event: dict) -> tuple:
    """生成去重三要素键: (日期, 公司名, 事件关键词)"""
    date = event.get("date", "")
    company = event.get("company", "") or normalize_company(event.get("title", ""), event.get("source", ""), event.get("note", ""))
    if event.get("type") == "股息分红":
        note = event.get("note", "")
        fiscal_year = re.search(r"财政年度:\s*([^；;]+)", note)
        distribution_type = re.search(r"分配类型:\s*([^；;]+)", note)
        return (
            date,
            company,
            event.get("ticker", ""),
            event.get("title", ""),
            fiscal_year.group(1).strip() if fiscal_year else "",
            distribution_type.group(1).strip() if distribution_type else "",
        )
    keyword = extract_event_keyword(event.get("title", ""))
    keyword = normalize_keyword(keyword)
    return (date, company, keyword)


def deduplicate_events(events: list) -> list:
    """
    去重规则：日期 + 公司名 + 事件关键词 三个相同项就要去重
    保留优先级高的来源（IR > RSS > 通用），同优先级保留最早的
    """
    SOURCE_PRIORITY = {
        "投资者关系": 100, "IR": 100, "投资者日历": 100, "业绩发布": 100,
        "Rss": 80, "RSS": 80,
        "AkShare": 70,
    }

    def get_priority(event):
        source = event.get("source", "")
        for keyword, priority in SOURCE_PRIORITY.items():
            if keyword in source:
                return priority
        return 50

    groups = {}
    for e in events:
        key = make_dedup_key(e)
        if key not in groups:
            groups[key] = []
        groups[key].append(e)

    result = []
    for key, group in groups.items():
        if len(group) == 1:
            result.append(group[0])
        else:
            group.sort(key=lambda x: (-get_priority(x), x.get("created_at", "")))
            winner = group[0]
            notes = set()
            last_notified = ""
            for e in group:
                n = e.get("note", "").strip()
                if n and n != "自动采集，请核实":
                    notes.add(n)
                ln = e.get("last_notified", "")
                if ln and (not last_notified or ln > last_notified):
                    last_notified = ln
            if notes and not winner.get("note"):
                winner["note"] = "; ".join(list(notes)[:2])
            if last_notified and not winner.get("last_notified"):
                winner["last_notified"] = last_notified
            result.append(winner)

    result.sort(key=lambda x: x.get("date", ""))
    return result





def load_data():
    """加载数据"""
    if EVENTS_FILE.exists():
        with open(EVENTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"events": [], "config": {}}


def save_data(data):
    """保存数据"""
    with open(EVENTS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def add_event(date_str, title, note="", event_type="其他"):
    """添加事件"""
    data = load_data()

    try:
        event_date = datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        print(f"❌ 日期格式错误，请使用 YYYY-MM-DD 格式")
        return False

    event = {
        "id": datetime.now().strftime("%Y%m%d%H%M%S"),
        "date": date_str,
        "title": title,
        "note": note,
        "type": event_type,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }

    data["events"].append(event)
    data["events"].sort(key=lambda x: x["date"])
    save_data(data)

    print(f"✅ 已添加事件: {date_str} - {title}")
    return True


def list_events(days=30):
    """列出未来N天内的事件"""
    data = load_data()
    events = data.get("events", [])

    if not events:
        print("📅 暂无投研事件")
        return

    now = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    future = now + timedelta(days=days)

    # 过滤垃圾事件（纯导航文本、纯时间字符串，但保留 RSS 格式日期前缀的有意义事件标题）
    GARBAGE_PATTERNS = [
        r'^\d{1,2}:\d{2}\s*(?:AM|PM|MDT|EDT|HKT|CST|CDT|EST|PDT|PST)$',
        r'^(?:Latest News|View all|Events & Presentations|Financial Events|Past Events|Upcoming Events)$',
    ]

    upcoming = []
    for event in events:
        title = event.get("title", "").strip()
        if not title or any(re.search(p, title) for p in GARBAGE_PATTERNS):
            continue
        try:
            event_date = datetime.strptime(event["date"], "%Y-%m-%d")
            if now <= event_date <= future:
                upcoming.append(event)
        except:
            continue

    # 去重
    upcoming = deduplicate_events(upcoming)

    if not upcoming:
        print(f"📅 未来{days}天内暂无投研事件")
        return

    upcoming.sort(key=lambda x: x.get("date", ""))

    print(f"📅 未来{days}天投研事件 ({len(upcoming)}条)")
    print()

    for i, event in enumerate(upcoming, 1):
        event_date = datetime.strptime(event["date"], "%Y-%m-%d")
        days_left = (event_date - datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)).days

        if days_left == 0:
            marker = "⚡ 今天"
        elif days_left <= 3:
            marker = f"🔴 还有{days_left}天"
        else:
            marker = f"🟡 还有{days_left}天"
        
        print(f"{i}. [{event['date']}] {marker}")
        print(f"   {event['title']}")

        source = event.get("source", "未知")
        print(f"   来源：{source}")
        print()


def main():
    """主函数"""
    import sys

    if len(sys.argv) < 2:
        print("用法:")
        print("  python3 calendar_notify.py add <日期> <标题> [备注] [类型]")
        print("  python3 calendar_notify.py list [天数]")
        print()
        print("示例:")
        print("  python3 calendar_notify.py add 2026-04-20 '英伟达财报' '关注AI芯片收入' 财报")
        print("  python3 calendar_notify.py list 30")
        return

    command = sys.argv[1]

    if command == "add":
        if len(sys.argv) < 4:
            print("❌ 参数不足")
            print("用法: python3 calendar_notify.py add <日期> <标题> [备注] [类型]")
            return

        date_str = sys.argv[2]
        title = sys.argv[3]
        note = sys.argv[4] if len(sys.argv) > 4 else ""
        event_type = sys.argv[5] if len(sys.argv) > 5 else "其他"

        add_event(date_str, title, note, event_type)

    elif command == "list":
        days = int(sys.argv[2]) if len(sys.argv) > 2 else 7
        list_events(days)

    else:
        print(f"❌ 未知命令: {command}")


if __name__ == "__main__":
    main()
